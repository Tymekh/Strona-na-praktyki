        <footer>
            <div id="footer_container">
                <p>&copy;&nbsp;2015 COPYRIGHT DESIGN STUDIO</p>
                <p>DESIGNED BY 
                    <img src="<?php echo get_template_directory_uri(); ?>/img/logo.png" alt="logo" id="logo">
                </p>
            </div>
        </footer>
    </div>
    <?php wp_footer(); ?>
</body>
</html>