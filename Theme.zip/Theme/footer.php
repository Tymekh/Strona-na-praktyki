<footer>
            <p>&copy;2015 COPYRIGHT TANATOS STUDIO</p>
            <p>DESIGNED BY <img src="<?php echo get_template_directory_uri(); ?>/img/logo.png" alt="logo" id="logo"></p>
        </footer>
    </div>
    <div class="side"></div>
    <?php wp_footer(); ?>
</body>
</html>